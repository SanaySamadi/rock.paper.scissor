from tkinter import *
import tkinter.messagebox
import random

# ===================== settings ======================
root = Tk()
root.title("Rock, Paper, Scissors")
root.geometry("350x450")
root.resizable(width=False, height=False)
color = '#75ff8f'
root.configure(bg=color)

# ==================== Load images ====================
rock_image = PhotoImage(file="rock.png")
paper_image = PhotoImage(file="paper.png")
scissor_image = PhotoImage(file="scissor.png")

# ====================== Scores =======================
user_score = 0
computer_score = 0

# ======================= frames ======================
Top_first = Frame(root, width=400, height=50, bg=color)
Top_first.pack(side='top')
Top_second = Frame(root, width=400, height=50, bg=color)
Top_second.pack(side='top')
Top_third = Frame(root, width=400, height=50, bg=color)
Top_third.pack(side='top')
Top_forth = Frame(root, width=400, height=50, bg=color)
Top_forth.pack(side='top')
Top_five = Frame(root, width=400, height=50, bg=color)
Top_five.pack(side='top')
Top_six = Frame(root, width=400, height=50, bg=color)
Top_six.pack(side='top')
Top_seven = Frame(root, width=400, height=50, bg=color)
Top_seven.pack(side='top')
Top_eight = Frame(root, width=400, height=50, bg=color)
Top_eight.pack(side='top')
Top_nine = Frame(root, width=400, height=50, bg=color)
Top_nine.pack(side='top')
Top_ten = Frame(root, width=400, height=50, bg=color)
Top_ten.pack(side='top')

# ========================== Buttons =====================
btn_1 = Button(
    Top_first, text=" Rock", image=rock_image, compound=LEFT, width=150, 
    highlightbackground=color, command=lambda: user_move("rock"))
btn_1.pack(side=LEFT, padx=5, pady=5)

btn_2 = Button(
    Top_second, text=" Paper", image=paper_image, compound=LEFT, width=150, 
    highlightbackground=color, command=lambda: user_move("paper"))
btn_2.pack(side=LEFT, padx=5, pady=5)

btn_3 = Button(
    Top_third, text=" Scissors", image=scissor_image, compound=LEFT, width=150, 
    highlightbackground=color, command=lambda: user_move("scissor"))
btn_3.pack(side=LEFT, padx=5, pady=5)

btn_user = Button(Top_forth, text="", width=150, highlightbackground=color, compound=LEFT)
btn_user.pack(side=LEFT, padx=5, pady=5)

btn_4 = Button(Top_five, text="", width=150, highlightbackground=color, compound=LEFT)
btn_4.pack(side=LEFT, padx=5, pady=5)

btn_5 = Label(Top_seven, text="", width=30, bg=color, font=("Arial", 12, "bold"))
btn_5.pack(side=LEFT, padx=5, pady=5)

btn_6 = Button(Top_eight, text="Creator", width=5, highlightbackground=color, command=lambda: creator())
btn_6.pack(side=LEFT, padx=5, pady=5)
btn_7 = Button(Top_eight, text="Clear", width=5, highlightbackground=color, command=lambda: clear())
btn_7.pack(side=LEFT, padx=5, pady=5)

# ========================= Functions =====================
def creator():
    tkinter.messagebox.showinfo("CREATOR", "This game was created by Sanay Samadi")

def update_score():
    score_label.config(text=f"User: {user_score}    Computer: {computer_score}")

def user_move(choice):
    global user_score, computer_score

    if choice == "rock":
        btn_user.config(image=rock_image, text=" Rock", compound=LEFT)
        user_choice = 0
    elif choice == "paper":
        btn_user.config(image=paper_image, text=" Paper", compound=LEFT)
        user_choice = 1
    else:
        btn_user.config(image=scissor_image, text=" Scissors", compound=LEFT)
        user_choice = 2

    z = random.randint(0, 2)
    if z == 0:
        btn_4.config(image=rock_image, text=" Rock", compound=LEFT)
    elif z == 1:
        btn_4.config(image=paper_image, text=" Paper", compound=LEFT)
    else:
        btn_4.config(image=scissor_image, text=" Scissors", compound=LEFT)

    if z == user_choice:
        btn_5['text'] = "It's a tie!"
        btn_5['fg'] = "black"
    elif (user_choice == 0 and z == 2) or (user_choice == 1 and z == 0) or (user_choice == 2 and z == 1):
        btn_5['text'] = "You win!"
        btn_5['fg'] = "green"
        user_score += 1
    else:
        btn_5['text'] = "You lose!"
        btn_5['fg'] = "red"
        computer_score += 1

    update_score()
    if user_score == 5:
        tkinter.messagebox.showinfo("Game Over", "Congratulations ! You won the game !")
        clear()
    elif computer_score == 5:
        tkinter.messagebox.showinfo("Game Over", "Computer wins the game . Better luck next time !")
        clear()

def clear():
    global user_score, computer_score
    btn_user.config(image='', text='')
    btn_4.config(image='', text='')
    btn_5['text'] = ''
    user_score = 0
    computer_score = 0
    update_score()

# ======================== Labels =======================
Label(Top_nine, text="Your Move    vs    Computer Move", bg=color).pack(padx=5, pady=5)
g = Label(Top_six, text="Result:", bg=color)
g.pack(side=LEFT, padx=5, pady=5)

score_label = Label(Top_ten, text="User: 0    Computer: 0", bg=color, font=("Helvetica", 12, "bold"))
score_label.pack()

# =========================== Run ========================
root.mainloop()